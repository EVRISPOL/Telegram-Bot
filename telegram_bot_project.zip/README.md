# Telegram Bot

Ένας απλός Telegram bot που απαντά με polling.

## Οδηγίες

- Περιέχει αρχείο `.env` με το TOKEN
- Τρέχει με `python bot.py`
- Χρησιμοποιεί `python-telegram-bot` v20+
